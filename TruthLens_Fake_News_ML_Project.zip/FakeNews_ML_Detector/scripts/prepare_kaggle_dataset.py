import argparse
import pandas as pd

def main():
    p = argparse.ArgumentParser(description="Combine Kaggle Fake.csv and True.csv")
    p.add_argument("--fake", required=True)
    p.add_argument("--real", required=True)
    p.add_argument("--output", default="data/news.csv")
    args = p.parse_args()
    fake = pd.read_csv(args.fake)
    real = pd.read_csv(args.real)
    for frame in (fake, real):
        if "text" not in frame.columns:
            raise SystemExit("Expected a 'text' column in both files.")
    fake = fake[["text"]].copy()
    fake["label"] = "FAKE"
    real = real[["text"]].copy()
    real["label"] = "REAL"
    combined = pd.concat([fake, real], ignore_index=True)
    combined["text"] = combined["text"].fillna("").astype(str).str.strip()
    combined = combined[combined["text"].str.len() > 40]
    combined = combined.drop_duplicates(subset=["text"])
    combined = combined.sample(frac=1, random_state=42).reset_index(drop=True)
    combined.to_csv(args.output, index=False)
    print(f"Saved {len(combined):,} rows to {args.output}")

if __name__ == "__main__":
    main()
