from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from pathlib import Path
import sqlite3, joblib, json, io, csv, re
from datetime import datetime
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "history.db"
MODEL = ROOT / "models" / "fake_news_model.joblib"
METRICS = ROOT / "models" / "metrics.json"

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, title TEXT,
            text TEXT, prediction TEXT, fake_probability REAL, real_probability REAL
        )""")

def create_app():
    app = Flask(__name__)
    app.secret_key = "change-this-local-demo-secret"
    init_db()

    def load_model():
        return joblib.load(MODEL) if MODEL.exists() else None

    def metrics():
        if METRICS.exists():
            try: return json.loads(METRICS.read_text(encoding="utf-8"))
            except Exception: pass
        return {}

    def predict(text):
        model = load_model()
        if model is None: raise RuntimeError("Model not trained yet. Open Train Model and train it first.")
        probs = model.predict_proba([text])[0]
        classes = list(model.classes_)
        scores = {c: float(probs[i]) for i,c in enumerate(classes)}
        label = model.predict([text])[0]
        return label, scores.get("FAKE", 0.0), scores.get("REAL", 0.0)

    @app.route("/")
    def index():
        with get_db() as con:
            total = con.execute("SELECT COUNT(*) FROM predictions").fetchone()[0]
            fake = con.execute("SELECT COUNT(*) FROM predictions WHERE prediction='FAKE'").fetchone()[0]
            recent = con.execute("SELECT * FROM predictions ORDER BY id DESC LIMIT 6").fetchall()
        m = metrics()
        return render_template("index.html", total=total, fake=fake, real=total-fake,
                               recent=recent, m=m, trained=MODEL.exists())

    @app.route("/predict", methods=["GET","POST"])
    def predict_page():
        result = None
        if request.method == "POST":
            title = request.form.get("title","").strip()
            text = request.form.get("article","").strip()
            if len(text) < 30:
                flash("Please enter at least 30 characters of article text.", "error")
            else:
                try:
                    label, fp, rp = predict(text)
                    with get_db() as con:
                        con.execute("""INSERT INTO predictions
                        (created_at,title,text,prediction,fake_probability,real_probability)
                        VALUES (?,?,?,?,?,?)""",
                        (datetime.now().strftime("%Y-%m-%d %H:%M"), title, text, label, fp, rp))
                    # Show strongest weighted terms for a transparent, limited explanation.
                    model = load_model()
                    vec = model.named_steps["features"].transform([text])
                    clf = model.named_steps["classifier"]
                    names = model.named_steps["features"].get_feature_names_out()
                    weights = clf.coef_[0]
                    vals = vec.toarray()[0]
                    ranked = sorted([(float(vals[i]*weights[i]), names[i]) for i in range(len(names)) if vals[i] > 0],
                                    key=lambda x: abs(x[0]), reverse=True)[:7]
                    result = {"label":label, "fake":round(fp*100,1), "real":round(rp*100,1),
                              "terms":[x[1].replace("word__","").replace("char__","") for x in ranked[:5]]}
                except Exception as e:
                    flash(str(e), "error")
        return render_template("predict.html", result=result)

    @app.route("/batch", methods=["GET","POST"])
    def batch():
        if request.method == "POST":
            f = request.files.get("file")
            if not f or not f.filename.lower().endswith(".csv"):
                flash("Upload a CSV file.", "error")
                return redirect(url_for("batch"))
            try:
                df = pd.read_csv(f)
                col = request.form.get("column","text").strip()
                if col not in df.columns: raise ValueError(f"Column '{col}' not found. Columns: {list(df.columns)}")
                outputs=[]
                for text in df[col].fillna("").astype(str):
                    if len(text.strip()) < 30:
                        outputs.append(("TOO SHORT",0,0))
                    else:
                        label, fp, rp = predict(text)
                        outputs.append((label, round(fp*100,1), round(rp*100,1)))
                df["prediction"]=[x[0] for x in outputs]
                df["fake_probability_percent"]=[x[1] for x in outputs]
                df["real_probability_percent"]=[x[2] for x in outputs]
                buf=io.BytesIO(df.to_csv(index=False).encode("utf-8-sig")); buf.seek(0)
                return send_file(buf, mimetype="text/csv", as_attachment=True, download_name="fake_news_batch_results.csv")
            except Exception as e:
                flash(str(e), "error")
        return render_template("batch.html")

    @app.route("/history")
    def history():
        with get_db() as con:
            rows=con.execute("SELECT * FROM predictions ORDER BY id DESC LIMIT 100").fetchall()
        return render_template("history.html", rows=rows)

    @app.route("/train", methods=["GET","POST"])
    def train():
        status=None
        if request.method=="POST":
            data=request.form.get("data","data/sample_news.csv").strip()
            tc=request.form.get("text_column","text").strip()
            lc=request.form.get("label_column","label").strip()
            import subprocess, sys
            proc=subprocess.run([sys.executable,str(ROOT/"train_model.py"),"--data",data,
                                 "--text-column",tc,"--label-column",lc],
                                cwd=ROOT,capture_output=True,text=True,timeout=900)
            status=(proc.returncode, (proc.stdout or "") + (proc.stderr or ""))
        return render_template("train.html", status=status, m=metrics())

    @app.route("/about")
    def about(): return render_template("about.html")

    return app
