# Dataset guidance

The ZIP includes `sample_news.csv` only for a quick smoke test. It is deliberately tiny and **not suitable for meaningful accuracy claims**.

For a larger academic experiment, download **WELFake** from [Zenodo](https://zenodo.org/records/4561253) (DOI: `10.5281/zenodo.4561253`). It contains 72,134 English articles (35,028 fake, 37,106 real); its CSV is about 245 MB. Columns include `Title`, `Text`, and `Label`, where `0 = FAKE` and `1 = REAL`. Review license, provenance, and labeling method before use. Do not treat dataset labels as ground truth without scrutiny.

Another common option is Kaggle's "Fake and Real News Dataset" (separate `Fake.csv` and `True.csv`). Download it from Kaggle yourself, then run:
```powershell
python scripts/prepare_kaggle_dataset.py --fake data/Fake.csv --real data/True.csv --output data/news.csv
```
The resulting file has `text` and `label` columns. Do not redistribute datasets unless their license permits it.

For any dataset, remove duplicates and empty rows, check class balance, inspect label definitions, and avoid train/test leakage from duplicate or near-duplicate articles.
